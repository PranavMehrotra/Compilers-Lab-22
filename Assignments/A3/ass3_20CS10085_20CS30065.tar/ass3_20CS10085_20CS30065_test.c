/* Group members: **Pranav Mehrotra(20CS10085)**
                  **Saransh Sharma (20CS30065)** */
#include<iostream>
#include<stdlib.h>
#include<string>
using namespace std;

/* include headers


        */

typedef struct HashNode{//structure defination
char* key;
int value;
}HashNode;

int main(void)
{
    unsigned int a=234533,b,c;//variable declaration
    float c=2.34e+89,d=3.48,e=234.e90;
    
    
    char d='h';
    printf("Hello world\n");//print message
    for(a=1; a<n;i++)
    {
        x++;
    }

    while(a)
    {
        b++;
    }
    c='\n';

    if(variable1==2)
    {
        printf("This is variable 1\t\n");
    }
    else 
    {
        printf("This is variable 2");
    }
    switch(1)
    {
        case 1:
            a++;
        case 2:
            b++;
    }
    
    int dequeue(QUEUE *qP)
    {
    int a = qP->Arr[(qP->start_id)+1];
    qP->start_id =(((qP->start_id)+1));//to delete an element
    return a;
    }
    void display_queue(QUEUE *qP)
    {
        int i;
        for(i=qP->start_id+1;i<=(qP->end_id);++i)
        printf("%d,",qP->Arr[i]);//print the elements of the queue
    }
    float a = 2.34E98 + 2.566e-90;
    if(a>b)printf("hello this is a");
    else printf("this is b");
    
    //some single line comments to check with               multiple tabs


    /* some     multiline commenst with multiple spaces tabs and newline.
    **
    //

    */

    return 0;

}//return from main
